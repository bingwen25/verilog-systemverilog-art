from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
import re,json,hashlib
root=Path(__file__).resolve().parent
s=(root/'RTL_Art_Manuscript.md').read_text()
chap=[int(x) for x in re.findall(r'^# 第(\d+)章',s,re.M)]
assert chap==list(range(1,34)),chap
sections=re.findall(r'^## (\d+\.\d+)\s',s,re.M)
assert len(sections)==len(set(sections)),[k for k,n in Counter(sections).items() if n>1]
for ch in 'ABCDEFG': assert re.search('^# 附录'+ch,s,re.M)
fence=None
for line in s.splitlines():
 m=re.match(r'^(```|~~~)',line)
 if m:
  if fence is None:fence=m.group(1)
  elif fence==m.group(1):fence=None
assert fence is None
blocks=[b.strip() for b in s.split('\n\n') if len(b.strip())>180]
dups=[(n,b[:100]) for b,n in Counter(blocks).items() if n>1]
assert not dups,dups
for token in ['尚未撰写','本交付环境中未发现','前一分支使响应优先','\\`']:
 assert token not in s,token
class Check(HTMLParser):
 def __init__(self): super().__init__();self.ids=[];self.refs=[];self.tables=0;self.pres=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag=='a' and a.get('href','').startswith('#'):self.refs.append(a['href'][1:])
  if tag=='table':self.tables+=1
  if tag=='pre':self.pres+=1
c=Check();c.feed((root/'RTL_Art_Reader.html').read_text())
assert len(c.ids)==len(set(c.ids))
assert not set(c.refs)-set(c.ids)
assert c.tables>=20 and c.pres>=25
logchecks={}
for log,marker in [('run.log','PASS all examples'),('bridge-iverilog.log','PASS: bounded AXI4-Lite CSR scenarios completed'),('pyslang.log','ERRORS: 0 DIAGNOSTICS: 0'),('bridge-pyslang.log','ERRORS: 0 DIAGNOSTICS: 0'),('sva-syntax.log','ERRORS: 0 DIAGNOSTICS: 0')]:
 data=(root/'examples/logs'/log).read_text();assert marker in data;logchecks[log]=marker
report={'status':'passed','chapters':chap,'appendices':list('ABCDEFG'),'characters':len(s),'cjk_characters':len(re.findall(r'[\u3400-\u9fff]',s)),'numbered_sections':len(sections),'html_ids':len(c.ids),'html_tables':c.tables,'html_code_blocks':c.pres,'duplicate_long_blocks':dups,'execution_log_markers':logchecks,'manuscript_sha256':hashlib.sha256(s.encode()).hexdigest(),'limitations':'Structural and static HTML validation only; no browser layout screenshot or publication proof review. HDL execution scope is limited to recorded example configurations.'}
(root/'quality_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
