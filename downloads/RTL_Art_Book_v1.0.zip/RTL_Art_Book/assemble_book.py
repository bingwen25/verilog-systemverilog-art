from pathlib import Path
import re
root=Path(__file__).resolve().parent
original=(root/'RTL_Art_Manuscript_v0.1.md').read_text()
front, first=original.split('# 第一篇　设计哲学与工程方法',1)
front=front.replace('版本：v0.1／2026-11-14','版本：完整初稿 v1.0／2026-11-14')
front=front.replace('状态：写作中的书稿；第一篇三章初稿，其余章节为定稿目录，尚未撰写。','状态：六篇33章、附录A—G及三个工程案例正文已齐备；这是待出版审校的完整初稿，检查结果见文末验证记录。')
front=front.replace('本版没有声称完成仿真、综合或物理实现。第一篇的代码是语义推演片段；完整可运行工程与机器执行证据将在对应实现章节建立。未经执行的例子，不标记为“测试通过”。','正文含语义推演片段，配套工程另含完整RTL、轻量自检TB和运行入口。片段不能直接作为完整模块编译；只有执行记录明确列出的文件、配置与检查才具备相应证据。尚未执行的仿真、综合、形式化与物理检查不标为通过。')
front=front.replace('AXI4-Lite 到内部 CSR 接口桥','AXI4-Lite CSR 从设备')
front=front.replace('具体协议契约在第18章前核对官方规范后冻结，不能把这个教学子集宣称为任意配置的通用桥。','最终契约见案例C；该教学实现不承诺任意配置的通用桥行为。')
first=first.split('# 参考资料与核对状态',1)[0]
chunks=[front,'# 第一篇　设计哲学与工程方法\n'+first]
for name in ['part2.md','part3.md','part4_5.md','part6_appendices.md']:
    s=(root/name).read_text().replace('\\`','`')
    s=re.sub(r'^#+ (第\d+章[^\n]*)',r'# \1',s,flags=re.M)
    s=re.sub(r'^### (\d+\.\d+[^\n]*)',r'## \1',s,flags=re.M)
    s=re.sub(r'^## (附录[A-G][^\n]*)',r'# \1',s,flags=re.M)
    s=s.replace('# 第三编：工业 RTL 的控制与数据通路','# 第三篇　RTL 结构与微架构设计').replace('# 第六编 工业 RTL 的工程化与交付','# 第六篇　编码规范与工程实践')
    chunks.append(s)
chunks.append((root/'bridge_case.md').read_text())
chunks.append((root/'delivery_status.md').read_text())
s='\n\n'.join(chunks)
# Make reference URLs clickable without changing fenced or indented code.
lines=[]; fenced=False
for line in s.splitlines():
    if re.match(r'^\s*(```|~~~)',line): fenced=not fenced
    if not fenced and not line.startswith('    '):
        line=re.sub(r'(?<![\(<\[])https?://[A-Za-z0-9./_?=&%:+~#@-]+',lambda m:'['+m.group()+']('+m.group()+')',line)
    lines.append(line)
s='\n'.join(lines)+'\n'
(root/'RTL_Art_Manuscript.md').write_text(s)
chapters=[int(x) for x in re.findall(r'^# 第(\d+)章',s,re.M)]
assert chapters==list(range(1,34)),chapters
for ch in 'ABCDEFG': assert re.search(r'^# 附录'+ch,s,re.M),ch
assert '尚未撰写' not in s
assert not fenced
print('33 chapters, 7 appendices; manuscript characters:',len(s),'bytes:',len(s.encode()))
