# 《Verilog/SystemVerilog 编程艺术》完整初稿 v1.0

本书面向工业级 RTL 设计，以“系统解释优秀 RTL 为什么如此设计”为主线。全书六篇33章，附录A—G，附Timer、同步FIFO、受限AXI4-Lite CSR从设备三个案例。

## 阅读入口

| 文件 | 用途 |
|---|---|
| `RTL_Art_Reader.html` | 离线阅读版，含章节导航、全文浏览器查找与打印样式 |
| `RTL_Art_Manuscript.md` | 完整可编辑书稿 |
| `part2.md`、`part3.md`、`part4_5.md`、`part6_appendices.md` | 分篇编辑源；第一篇来自保留的v0.1书稿 |
| `bridge_case.md` | 最终综合案例正文 |
| `delivery_status.md` | 本次检查范围与尚未完成的出版审校项目 |
| `examples/` | 可运行RTL、自检TB、运行脚本与实际日志 |

## 复现案例

进入 `examples/`，按其README运行。基础工程需要Icarus Verilog；协议检查器单独需要支持相应SVA的工具，不放入默认Icarus构建。代码中的测试PASS文字只是执行成功时的输出，是否实际执行以日志与验证记录为准。

## 重建阅读版

安装Python包 `Markdown==3.11.3` 后，可运行：

```sh
python3 assemble_book.py
python3 build_reader.py
```

也可通过原书稿直接重建排版，不影响RTL仿真。阅读版无需联网；引用的外部规范链接需网络访问。第一篇v0.1文件保留为编辑来源，不代表本交付仍只有前三章。

## 版本和责任边界

v1.0完成全书正文覆盖、练习答案、设计审查材料和三案例初步工程验证。它是完整初稿，尚不是经过独立技术审稿、标准逐条校对和目标工艺实现验证的出版定稿。没有附带商业综合、STA、功耗、形式化或流片签核结论。
